Title: Lewis Grassic Gibbon First Editions
Description: This dataset contains 1 plain text readme file, 1 inventory csv file and 16 plain text files.
Owner: National Library of Scotland
Creator: National Library of Scotland
Website: https://data.nls.uk/
DOI: https://doi.org/10.34812/a61z-m825
Date created: 13/7/2020
Rights: Items in this dataset are free of known copyright and in the public domain.
Contact: digital.scholarship@nls.uk
